import React from 'react';
import './App.css';
//import Protected from './components/Protected'
import Auth from './components/Auth'
//import Nav from './components/Nav'
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";

function App() {
  return (
    <div className="App">
        
        <Router>
            <Link to="/">Login</Link>
            {/*<Nav/>*/}
            <Switch>
              
              <Route path="/">
              <Auth/>
              </Route>
            </Switch>

            

        </Router>
    </div>
  );
}

export default App;

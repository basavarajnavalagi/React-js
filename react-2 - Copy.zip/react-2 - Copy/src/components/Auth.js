import React, { Component } from 'react'
import {
  Redirect
} from "react-router-dom";

export class Auth extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             isRegister: false
        }
    }
    
    login()
    {
        console.warn("state",this.state)
        fetch('http://127.0.0.1:8000/api/login',{
            method: "POST",
            headers:{
                "Accept":"application/json",
                "Content-Type":"application/json"
            },
            body:JSON.stringfy(this.state)
        })
        .then((result) => {
            result.json().then((response)=> {
                console.log(response);
                localStorage.setItem("auth" , JSON.stringify(response.success.token))
            })
        })
    }
    register()
    {
        console.warn("state",this.state)
        fetch('http://127.0.0.1:8000/api/register',{
            method: "POST",
            headers:{
                "Accept":"application/json",
                "Content-Type":"application/json"
            },
            body:JSON.stringfy(this.state)
        })
        .then((result) => {
            result.json().then((response)=> {
                console.log(response);
                localStorage.setItem("auth" , JSON.stringify(response.success.token))
            })
        })
    }
    render() {

        var auth =JSON.parse(localStorage.getItem('auth'))
        return (
            <div>
            {
                auth ?  <Redirect to ="/home"/>:null
            }
            {
                this.state.isRegister ?
                <div>
                    <input type="text" 
                    placeholder= "email"
                    onChange = {(e) => {this.setState({email:e.target.value})}}
                    /><br /><br />
                    <input type="text" 
                    placeholder= "password"
                    onChange = {(e) => {this.setState({password:e.target.value})}}
                    /><br /><br />
                    <button onClick={() => this.login()} >Login</button>
                    <button onClick={() => this.setState({isRegister: true})} > Register</button>
                </div>
                :
                <div>
                    <input type="text" 
                    placeholder= "name"
                    onChange = {(e) => {this.setState({name:e.target.value})}}
                    /><br /><br />
                    <input type="text" 
                    placeholder= "gender"
                    onChange = {(e) => {this.setState({gender:e.target.value})}}
                    /><br /><br />
                    <input type="text" 
                    placeholder= "Mobile"
                    onChange = {(e) => {this.setState({Mobile:e.target.value})}}
                    /><br /><br />
                    <input type="text" 
                    placeholder= "email"
                    onChange = {(e) => {this.setState({email:e.target.value})}}
                    /><br /><br />
                    <input type="text" 
                    placeholder= "password"
                    onChange = {(e) => {this.setState({password:e.target.value})}}
                    /><br /><br />
                    <input type="text" 
                    placeholder= "confirm-password"
                    onChange = {(e) => {this.setState({confirm_password:e.target.value})}}
                    /><br /><br />
                    <button onClick={() => this.login()} >Register</button>
                    <button onClick={() => this.setState({isRegister: true})} >Login</button>

                </div>
               
            }
                            
            </div>
        )
    }
}

export default Auth
